// signals.c
// contains signal handler funtions
// contains the function/s that set the signal handlers

/*******************************************/
/* Name: handler_cntlc
   Synopsis: handle the Control-C */
#include "signals.h"
#include <string.h>
#include <string>
#include "job.h"
#include <signal.h>
#include <time.h>
#include <algorithm>

using namespace std;
extern jobs fg_job;
extern vector<jobs> job_list; 


void ctrl_c_handler (int signum){
	
	if(signum != SIGINT || fg_job.getProcessID() == -1){
		return;
	}
	printf("smash: caught ctrl-C\n");
	if(kill(fg_job.getProcessID(),SIGKILL) == -1){
		perror("smash error: kill failed");
		return;
	}
	printf("smash: process %d was kill\n",fg_job.getProcessID());
	//remove job from foreground
	fg_job.setProcessID(-1);
	return;
	
}

void ctrl_z_handler(int signum){
	if(signum != SIGTSTP || fg_job.getProcessID() == -1 ){
		return;
	}
	printf("smash: caught ctrl-Z\n");
	if(kill(fg_job.getProcessID(),SIGSTOP) == -1){
		perror("smash error: kill failed");
		return;
	}
	printf("smash: process %d was stopped\n",fg_job.getProcessID());
	
	//add stopped job to job list
	if(!job_list.empty()){
		int index;
		int job_id ;
		double insert_time;
		if(fg_job.getJobID() == 0){
			index = (job_list.size())-1;
			job_id = (job_list[index].getJobID())+1;
			insert_time = time(NULL);
		}
		else {
			job_id = fg_job.getJobID();
			insert_time = time(NULL);
		}
		
		job_list.emplace_back(insert_time,fg_job.getProcessID(),job_id,STOPPED,fg_job.getCmd());
		sort(job_list.begin(), job_list.end(), compare_jobID);
	}
	else {
		int first = 1;
		double insert_time = time(NULL);
		int first_pid = fg_job.getProcessID();
		cmd_status first_st = STOPPED;
		char* first_cmd = fg_job.getCmd();
		job_list.emplace_back(insert_time,first_pid,first,first_st,first_cmd);
	}
	
	
	//remove job from foreground
	fg_job.setProcessID(-1);

	return;
	
	
}


string get_sig_name(int signum){
	switch(signum){
	case 1: return "SIGHUP";
		break;
	case 2: return "SIGINT";
		break;
	case 3: return "SIGQUIT";
		break;
	case 4: return "SIGILL";
		break;
	case 5: return "SIGTRACE";
		break;
	case 6: return "SIGABORT";
		break;
	case 7: return "SIGBUS";
		break;
	case 8: return "SIGFLOAT";
		break;
	case 9: return "SIGKILL";
		break;
	case 10: return "SIGUSER1";
		break;
	case 11: return "SIGSEGFAULT";
		break;
	case 12: return "SIGUSER2";
		break;
	case 13: return "SIGBROKENPIPE";
		break;
	case 14: return "SIGALARMCLK";
		break;
	case 15: return "SIGTERM";
		break;
	case 16: return "SIGSTACK";
		break;
	case 17: return "SIGCHILD";
		break;
	case 18: return "SIGCONT";
		break;
	case 19: return "SIGSTOP";
		break;
	case 20: return "SIGSTP";
		break;
	case 21: return "SIGSTOPTTYIN";
		break;
	case 22: return "SIGSTOPTTYOUT";
		break;
	case 23: return "SIGURGENTIO";
		break;
	case 24: return "SIGCPUTIME";
		break;
	case 25: return "SIGFILESIZE";
		break;
	case 26: return "SIGVIRTIMER";
		break;
	case 27: return "SIGPROFTIMER";
		break;
	case 28: return "SIGWINDOW";
		break;
	case 29: return "SIGIOPOSIBLE";
		break;
	case 30: return "SIGPOWER";
		break;
	case 31: return "SIGBADSYSCALL";
		break;
	default: return "";
	}
	return NULL;
}


