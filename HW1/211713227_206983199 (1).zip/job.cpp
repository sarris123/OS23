
#include "job.h"
#include <stdio.h>
#include <vector>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h> 
#include <stdlib.h>
#include <string.h>
#include <signal.h>

using namespace std; //not sure

extern vector<jobs> job_list;

void JobDone (vector<jobs>& job_list){
	for(vector<jobs>::iterator it = job_list.begin(); it != job_list.end();){
		if(waitpid(it->getProcessID(),NULL,WNOHANG) != 0 ){
			///waitpid is returning -1 and that is a problem
			
			job_list.erase(it);
		}else{
			++it;
		}

	}
}

//helper functions
int FindJobPID(vector<jobs>& job_list,int job_id){
	for(vector<jobs>::iterator it = job_list.begin(); it != job_list.end();){
		if(it->getJobID() == job_id){
			return (it->getProcessID());
		}else{
			++it;
		}
	}
	return -1;
}


int MaxStopJobID(vector<jobs>& job_list){
	if(job_list.size() == 0){
		//list is empty
		return -1;
	}
	for(vector<jobs>::iterator it = (job_list.end()-1); it != (job_list.begin()-1);){
		if(it->getStatus() == STOPPED){
			return (it->getJobID());
		}else{
			--it;
		}
	}
	return -1;
}


vector<jobs>::iterator find_job_index(vector<jobs>& job_list,int job_id){
	for(vector<jobs>::iterator it = job_list.begin(); it != job_list.end();){
		if(it->getJobID() == job_id){
			return it;
		}else{
			++it;
		}
	}
	return (job_list.end());
}

void removejob(vector<jobs>& job_list,int job_id){
		for(vector<jobs>::iterator it = job_list.begin(); it != job_list.end();){
			if(it->getJobID() == job_id){
				job_list.erase(it);
				break;
			}
			else {
				++it;
			}
		}
}

bool compare_jobID(const jobs& j1, const jobs& j2){
		return (j1.getJobID() < j2.getJobID());
	}


