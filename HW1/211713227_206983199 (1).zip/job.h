#ifndef JOB_H_
#define JOB_H_

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <vector>
#include <stdbool.h>
#define DEFULT_ID 0
#define MAX_CMD_LEN 80


typedef enum {STOPPED = 0 , BG = 1} cmd_status;
using namespace std;

 

class jobs{
	private:
	double time;
	int process_ID;
	int job_id;
	cmd_status status;
	char* cmd;
	
	//defult constructor
	
	public: 
	jobs(){
		time = -1;
		process_ID = DEFULT_ID;
		job_id = 0;
		status = BG;
		cmd = new char[MAX_CMD_LEN];
		cmd[0]='\0';
	}
	
	//constructor

	jobs(double t,int pid,int jid,cmd_status s,char* c){
		this->time = t;
        this->process_ID = pid;
        this->job_id = jid;
        this->status = s;
        this->cmd = new char[strlen(c) + 1]; // allocate memory for the string
        strcpy(this->cmd, c);
	}
															
	//copy constructor
	jobs(const jobs &j){
		time = j.time;
		process_ID = j.process_ID;
		job_id = j.job_id;
		status = j.status;
		cmd = new char[strlen(j.cmd) + 1];
		strcpy(cmd,j.cmd);
	}
	
	//operator&=
	jobs& operator=(const jobs& j){
		if(this != &j){
			time = j.time;
			process_ID = j.process_ID;
			job_id = j.job_id;
			status = j.status;
			delete[] cmd; // deallocate old memory for cmd
            cmd = new char[strlen(j.cmd) + 1]; // allocate new memory for cmd
            strcpy(cmd, j.cmd); 
		}
		return *this;
	}
	
	//destructor
	~jobs(){
		delete[] cmd;
	}

	//class functions
	double getTime() const { return time; }
    int getProcessID() const { return process_ID; }
    int getJobID() const { return job_id; }
    cmd_status getStatus() const { return status; }
    char* getCmd() const { return cmd; }

    void setTime(double newTime) { time = newTime; }
    void setProcessID(int newProcessID) { process_ID = newProcessID; }
    void setJobID(int newJobID) { job_id = newJobID; }
    void setStatus(cmd_status newStatus) { status = newStatus; }
    void setCmd(const char* newCmd) {
    	if (cmd != nullptr) {
    	    delete[] cmd;
        }
   	    cmd = new char[strlen(newCmd) + 1];
    	strcpy(cmd, newCmd);
	}

	
};


//helper function
vector<jobs>::iterator find_job_index(vector<jobs>& job_list,int job_id);

int MaxStopJobID(vector<jobs>& job_list);

int FindJobPID(vector<jobs>& job_list,int job_id);

void JobDone(vector<jobs>& job_list);

void removejob(vector<jobs>& job_list,int job_id);

//void print_jobs_vector(const vector<jobs>& jobs_vector);

bool compare_jobID(const jobs& j1, const jobs& j2);
	

#endif // !JOB_H
	
	
	
